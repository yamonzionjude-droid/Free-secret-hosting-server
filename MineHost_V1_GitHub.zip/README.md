# MineHost V1

Mobile-first Minecraft hosting dashboard for GitHub Pages.

## Publish from a phone

1. Create a GitHub repository, for example `minehost-v1`.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Open the GitHub Pages URL shown by GitHub.

## Important
GitHub Pages only hosts the dashboard. It does not run a Minecraft server.
V1 is a frontend prototype with local browser storage. V2 can connect the controls to an actual server backend/provider.
